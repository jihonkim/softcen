package bigcensaSample;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import kr.co.softcen.bigcensa.elasticsearch.client.Rest;
import kr.co.softcen.bigcensa.elasticsearch.client.request.Highlight;
import kr.co.softcen.bigcensa.elasticsearch.client.request.HighlightField;
import kr.co.softcen.bigcensa.elasticsearch.client.request.Match;
import kr.co.softcen.bigcensa.elasticsearch.client.request.MatchField;
import kr.co.softcen.bigcensa.elasticsearch.client.request.MultiMatch;
import kr.co.softcen.bigcensa.elasticsearch.client.request.Query;
import kr.co.softcen.bigcensa.elasticsearch.client.request.Range;
import kr.co.softcen.bigcensa.elasticsearch.client.request.RangeField;
import kr.co.softcen.bigcensa.elasticsearch.client.request.SortOrder;
import kr.co.softcen.bigcensa.elasticsearch.client.request.Term;
import kr.co.softcen.bigcensa.elasticsearch.client.request.TermField;
import kr.co.softcen.bigcensa.elasticsearch.client.response.Hit;
import kr.co.softcen.bigcensa.elasticsearch.client.response.SearchResponse;
import kr.co.softcen.bigcensa.elasticsearch.client.util.Util;
import de.fau.cs.osr.utils.StringTools;

import java.util.Properties;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.ibatis.datasource.DataSourceFactory;
import org.apache.ibatis.datasource.pooled.PooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.jsoup.Jsoup;
import org.sweble.wikitext.engine.EngineException;
import org.sweble.wikitext.engine.PageId;
import org.sweble.wikitext.engine.PageTitle;
import org.sweble.wikitext.engine.WtEngineImpl;
import org.sweble.wikitext.engine.config.WikiConfig;
import org.sweble.wikitext.engine.nodes.EngProcessedPage;
import org.sweble.wikitext.engine.output.HtmlRenderer;
import org.sweble.wikitext.engine.output.HtmlRendererCallback;
import org.sweble.wikitext.engine.output.MediaInfo;
import org.sweble.wikitext.engine.utils.DefaultConfigEnWp;
import org.sweble.wikitext.engine.utils.UrlEncoding;
import org.sweble.wikitext.example.App;
import org.sweble.wikitext.example.TextConverter;
import org.sweble.wikitext.parser.nodes.WtUrl;
import org.sweble.wikitext.parser.parser.LinkTargetException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import bigcensaSample.MyDataSourceFactory;
import bigcensaSample.i;

class MyDataSourceFactory implements DataSourceFactory {

    private Properties prop;

    @Override
    public DataSource getDataSource() {

        PooledDataSource ds = new PooledDataSource();

        ds.setDriver(prop.getProperty("driver"));
        ds.setUrl(prop.getProperty("url"));
        ds.setUsername(prop.getProperty("user"));
        ds.setPassword(prop.getProperty("password"));

        return ds;
    }

    @Override
    public void setProperties(Properties prprts) {

        prop = prprts;
    }
}


public class saSample {

			
			private static SqlSessionFactory sesFact = null;

			public static void main(String[] args) throws Exception
			{
				Map InsertMap = new HashMap();
				
				//xml데이터 가져오기
				List getXmlList = getXmlData();

				
				
			}
			
			
			//html stripper
			public static String html2text(String html) {
    		    return Jsoup.parse(html).text();
    		}
			
			//Xmldata 불러오기
			public static List getXmlData() throws SAXException, IOException, ParserConfigurationException, LinkTargetException, DOMException, EngineException {
					
					String url = "C:\\workspace\\test\\kowiki.xml";
				  

					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					
					XMLParserHandler parserHandler = new XMLParserHandler();
					sp.parse(url, parserHandler);
				

					
					
					return parserHandler.getResultList();
			}
			 
			 

			 
		
			//text tag wiki 파서
			public static String textParser(Element el, String html) throws DOMException, EngineException, LinkTargetException {
				// Set-up a simple wiki configuration
	        		WikiConfig config = DefaultConfigEnWp.generate();

	        		final int wrapCol = 80;

	        		// Instantiate a compiler for wiki pages
	        		WtEngineImpl engine = new WtEngineImpl(config);

	        		// Retrieve a page
	        		PageTitle pageTitle = PageTitle.make(config, el.getNodeName());

	        		PageId pageId = new PageId(pageTitle, -1);


	        		// Compile the retrieved page
	        		EngProcessedPage cp = engine.postprocess(pageId, el.getTextContent(), null);
	        		
        			String ourHtml = HtmlRenderer.print(new MyRendererCallback(), config, pageTitle, cp.getPage());
        			   			
        			String resultHtml = ourHtml;

        			return resultHtml;
			}
			 
			public static final class MyRendererCallback	implements	HtmlRendererCallback {
				protected static final String LOCAL_URL = "";
	
				@Override
				public boolean resourceExists(PageTitle target)
				{
					// TODO: Add proper check
					return false;
				}
	
				@Override
				public MediaInfo getMediaInfo(String title, int width, int height)
				{
					// TODO: Return proper media info
					return null;
				}
	
				@Override
				public String makeUrl(PageTitle target)
				{
					String page = UrlEncoding.WIKI.encode(target.getNormalizedFullTitle());
					String f = target.getFragment();
					String url = page;
					if (f != null && !f.isEmpty())
						url = page + "#" + UrlEncoding.WIKI.encode(f);
					return LOCAL_URL + "/" + url;
				}
	
				@Override
				public String makeUrl(WtUrl target)
				{
					if (target.getProtocol() == "")
						return target.getPath();
					return target.getProtocol() + ":" + target.getPath();
				}
	
				@Override
				public String makeUrlMissingTarget(String path)
				{
					return LOCAL_URL + "?title=" + path + "&amp;action=edit&amp;redlink=1";
	
				}
			}
		 
		 

			 
			 //select
			 public static Map getDataList() throws Exception {
				 	
			        /*Connection con = null;
					PreparedStatement pstmt = null;   
			        ResultSet rs = null;
			        
			        try {
			        	
			        	 Class.forName("org.mariadb.jdbc.Driver");
					        con = DriverManager.getConnection(
									"jdbc:mariadb://192.168.70.232:3306/bigcensa",
									"sa",
									"Softcen1!"
									);
					        
					        
				        if( con != null ){ System.out.println("데이터 베이스 접속 성공"); }
 
			        }
			        catch (Exception e) { System.out.println("데이터 베이스 접속 실패"); }

			       
			        
			        pstmt = con.prepareStatement("SELECT * FROM bigcensa.WikiKorean");
		            
		            rs = pstmt.executeQuery();
		            
		           
		            while(rs.next()) {
		            	 System.out.println(rs.getString("rc_username"));
		            }
		            
		            con.close();*/
			        
				 	Properties prop = new Properties();
			        prop.setProperty("driver", "org.mariadb.jdbc.Driver");
			        prop.setProperty("url", "jdbc:mariadb://192.168.70.232:3306/bigcensa");
			        prop.setProperty("user", "sa");
			        prop.setProperty("password", "Softcen1!");
				 	
				 	
			        MyDataSourceFactory mdsf = new MyDataSourceFactory();
			        mdsf.setProperties(prop);
			        DataSource ds = mdsf.getDataSource();
				 
		            TransactionFactory trFact = new JdbcTransactionFactory();
			        Environment environment = new Environment("development", trFact, ds);
			        Configuration config = new Configuration(environment);
			        config.addMapper(i.class);

			        sesFact = new SqlSessionFactoryBuilder().build(config);
			        Map resultMap = new HashMap();
			        try (SqlSession session = sesFact.openSession()) {
			        	
			        	resultMap = session.selectOne("getDataList");
			            //System.out.println(vocaConceptId);
			            
			        }
			        //Map resultMap = (HashMap) rs;
			        return resultMap;


			 }
			 
			//System.out.println(parserHandler.getPage());

				
				/*//1.문서를 읽기위한 공장을 만들어야 한다.
		        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		         
		        //2.빌더 생성
		        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		         
		        //3.생성된 빌더를 통해서 xml문서를 Document객체로 파싱해서 가져온다
			    Document doc = dBuilder.parse(url);
			    doc.getDocumentElement().normalize();//문서 구조 안정화
			     
			    Element root = doc.getDocumentElement();
			     
			    NodeList n_list = root.getElementsByTagName("page");
			    Element el = null;
			    NodeList sub_n_list = null; //sub_n_list
			        Element sub_el = null; //sub_el
			         
			        Node v_txt = null;
			        String value="";
			         
			        String[] tagList = {"title","ns","id","parentid","timestamp","username","comment","model","format","text","sha1"};
			        //String[] tagMatchList = {"id","revision"};
			        
			    System.out.println(n_list.getLength());

			    List<Map> resultList = new ArrayList(); 

			    for(int i=0; i<n_list.getLength(); i++) {
			    	Map tmpMap = new HashMap();
			    	List<Map> tmpList = new ArrayList();
			    	el = (Element) n_list.item(i);
//			    	System.out.println(i+":::"+el.getTextContent());
			    	
			    	for(int k=0; k< tagList.length; k++) {
			    		sub_n_list = el.getElementsByTagName(tagList[k]);
			    		//System.out.println("태그 이름 :::: "+tagList[k]);
			        	//System.out.println(sub_n_list.item(0).getTextContent());
			        	
			        	
			        	for(int j=0; j<sub_n_list.getLength(); j++) {
			        		sub_el = (Element) sub_n_list.item(j);
			        		if("id".equals(sub_el.getTagName())){
			        			if(j==0) tmpMap.put("id", sub_el.getTextContent());
			        			else if(j==1) tmpMap.put("r_id", sub_el.getTextContent());
			        			else tmpMap.put("rc_id", sub_el.getTextContent());
			        		}
			        		else if("text".equals(sub_el.getTagName())) {
			        			tmpMap.put("text", textParser(sub_el, sub_el.getTextContent()));
			        			
			        		}
			        		else {
			        			tmpMap.put(sub_el.getTagName(), html2text(textParser(sub_el,sub_el.getTextContent())));

			        		}
			        		//System.out.println(html2text(sub_el.getTextContent()));

				        }
			        	
			        }
			    	resultList.add(tmpMap);
			    	//System.out.println(tmpMap);
			    }
			    
			   // System.out.println(resultList);
			    
			    return resultList;*/
}

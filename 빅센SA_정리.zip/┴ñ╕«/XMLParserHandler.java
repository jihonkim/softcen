package bigcensaSample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.jsoup.Jsoup;
import org.sweble.wikitext.engine.PageId;
import org.sweble.wikitext.engine.PageTitle;
import org.sweble.wikitext.engine.WtEngineImpl;
import org.sweble.wikitext.engine.config.WikiConfig;
import org.sweble.wikitext.engine.nodes.EngProcessedPage;
import org.sweble.wikitext.engine.output.HtmlRenderer;
import org.sweble.wikitext.engine.output.HtmlRendererCallback;
import org.sweble.wikitext.engine.output.MediaInfo;
import org.sweble.wikitext.engine.utils.DefaultConfigEnWp;
import org.sweble.wikitext.engine.utils.UrlEncoding;
import org.sweble.wikitext.parser.nodes.WtUrl;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class XMLParserHandler extends DefaultHandler{

	//부모 태그명
	private String parentTagName;
	
	// 시작 태그명
    private String startTagName;
 
    // 끝 태그명
    private String endTagName;

	private String pageContent;
	
    // String buffer
    private StringBuffer buffer = new StringBuffer();
    
    private String elementName = "";
    
	private Map<String,String> resultMap = new HashMap<String, String>();
    
    private List<Map> resultList = new ArrayList();
    
	private static SqlSessionFactory sesFact2 = null;		
    
    private int number = 0;
    
    private SqlSession session;
    
    public void startDocument()
    {
    	System.out.println("Start document");
	    /*try {
			setInsertMap();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    session = sesFact2.openSession();*/
    }

    public void endDocument()
    {
      System.out.println("End document");
      
      
      //session.close();
    }
    
    public void startElement(String uri, String name, String qName, Attributes atts)
    {
    	startTagName = qName;
    	
    	if(qName.equals("page")) {
    		this.parentTagName = "page";
    	}
    	else if(qName.equals("revision")) {
    		this.parentTagName = "revision";
    	}
    	else if(qName.equals("contributor")) {
    		this.parentTagName = "contributor";
    	}
        buffer.setLength(0);

    }
    
    public void endElement(String uri, String localName, String qName){
    	//System.out.println("End element, Name : " + qName);
    	endTagName = qName;
    	
    	if(qName.equals("page")) {
    		
    		this.number += 1;
    		this.parentTagName = "mediawiki";
    		System.out.println(number);
    		
/*    		Map tmpMap = new HashMap();

    		tmpMap.putAll(resultMap);
    		
    						
			session.insert("setInsertMap", tmpMap);
			session.commit();*/
    	
	


    	}
    	else if(qName.equals("revision")) {
    		this.parentTagName = "page";
    	}
    	else if(qName.equals("contributor")) {
    		this.parentTagName = "revision";
    	}
    	
    }
	
  //insert
	 public static void setInsertMap() throws Exception {
		 	Properties prop = new Properties();
	        prop.setProperty("driver", "org.mariadb.jdbc.Driver");
	        prop.setProperty("url", "jdbc:mariadb://192.168.70.232:3306/bigcensa");
	        prop.setProperty("user", "sa");
	        prop.setProperty("password", "Softcen1!");

	        MyDataSourceFactory mdsf = new MyDataSourceFactory();
	        mdsf.setProperties(prop);
	        DataSource ds = mdsf.getDataSource();

	        TransactionFactory trFact = new JdbcTransactionFactory();
	        Environment environment = new Environment("development", trFact, ds);
	        Configuration config = new Configuration(environment);
	        config.addMapper(i.class);

	        sesFact2 = new SqlSessionFactoryBuilder().build(config);
	       
	        
	 }
 // 시작태그와 끝태그 사이의 내용을 인식 했을 때 처리
    public void characters(char[] str, int start, int len) throws SAXException {
        String strVal = "";
    	buffer.append(str, start, len);
    	
    	strVal = buffer.toString().trim();    	
        // 태그명 중 'x' 와 'y'값만 추출해서 변수에 담는다.
    	
		try {
			if(this.startTagName.equals("title") && this.endTagName.equals("title")) {  	
				this.resultMap.put("title", strVal);			
			}
			else if(this.startTagName.equals("ns") && this.endTagName.equals("ns")) {
	   	    	this.resultMap.put("ns", strVal);	
			}
			else if(this.startTagName.equals("id") && this.endTagName.equals("id") && parentTagName.equals("page")) {
	   	    	this.resultMap.put("id", strVal);	
			}
			else if(this.startTagName.equals("id") && this.endTagName.equals("id") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("r_id",strVal);	
			}
			else if(this.startTagName.equals("parentid") && this.endTagName.equals("parentid") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("parentid",strVal);	
			}
			else if(this.startTagName.equals("timestamp") && this.endTagName.equals("timestamp") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("timestamp", strVal);	
			}
			
			else if(this.startTagName.equals("username") && this.endTagName.equals("username") && parentTagName.equals("contributor")) {
	   	    	this.resultMap.put("username",strVal);	
			}
			else if(this.startTagName.equals("id") && this.endTagName.equals("id") && parentTagName.equals("contributor")) {
	   	    	this.resultMap.put("rc_id", strVal);	
			}
			
			else if(this.startTagName.equals("comment") && this.endTagName.equals("comment") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("comment", textParser("comment",strVal));	
			}
			else if(this.startTagName.equals("model") && this.endTagName.equals("model") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("model",strVal);	
			}
			else if(this.startTagName.equals("format") && this.endTagName.equals("format") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("format", strVal);	
			}
			else if(this.startTagName.equals("text") && this.endTagName.equals("text") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("text", textParser("text",strVal));	
			}
			else if(this.startTagName.equals("sha1") && this.endTagName.equals("sha1") && parentTagName.equals("revision")) {
	   	    	this.resultMap.put("sha1",strVal);	
			}
			else
			{
				this.resultMap.put("err", strVal);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
//		catch (DOMException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (EngineException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (LinkTargetException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	

        
    }
    
  //html stripper
	public static String html2text(String html) {
	    return Jsoup.parse(html).text();
	}
	
	//text tag wiki 파서
//	public static String textParser(String tag, String html) throws DOMException, EngineException, LinkTargetException {
	public String textParser(String tag, String html) throws Exception {
		// Set-up a simple wiki configuration
    		WikiConfig config = DefaultConfigEnWp.generate();

    		final int wrapCol = 80;

    		// Instantiate a compiler for wiki pages
    		WtEngineImpl engine = new WtEngineImpl(config);

    		// Retrieve a page
    		PageTitle pageTitle = PageTitle.make(config, tag);

    		PageId pageId = new PageId(pageTitle, -1);


    		// Compile the retrieved page
    		EngProcessedPage cp = engine.postprocess(pageId, html, null);
    		
    		System.out.println(cp.toString());
    		
			//String ourHtml = HtmlRenderer.print(new MyRendererCallback(), config, pageTitle, cp.getPage());
			String ourHtml = "";
			   			
			String resultHtml = ourHtml;

			return resultHtml;
	}
	 
//	private static final class MyRendererCallback	implements	HtmlRendererCallback {
//		protected static final String LOCAL_URL = "";
//
//		@Override
//		public boolean resourceExists(PageTitle target)
//		{
//			// TODO: Add proper check
//			return false;
//		}
//
//		@Override
//		public MediaInfo getMediaInfo(String title, int width, int height)
//		{
//			// TODO: Return proper media info
//			return null;
//		}
//
//		@Override
//		public String makeUrl(PageTitle target)
//		{
//			String page = UrlEncoding.WIKI.encode(target.getNormalizedFullTitle());
//			String f = target.getFragment();
//			String url = page;
//			if (f != null && !f.isEmpty())
//				url = page + "#" + UrlEncoding.WIKI.encode(f);
//			return LOCAL_URL + "/" + url;
//		}
//
//		@Override
//		public String makeUrl(WtUrl target)
//		{
//			if (target.getProtocol() == "")
//				return target.getPath();
//			return target.getProtocol() + ":" + target.getPath();
//		}
//
//		@Override
//		public String makeUrlMissingTarget(String path)
//		{
//			return LOCAL_URL + "?title=" + path + "&amp;action=edit&amp;redlink=1";
//
//		}
//	}
	
 // 추출 값 가져오기
    public Map getResultMap() {
        return resultMap;
    }

    public List<Map> getResultList() {
        return resultList;
    }


}

class MyRendererCallback implements	HtmlRendererCallback {
protected static final String LOCAL_URL = "";

@Override
public boolean resourceExists(PageTitle target)
{
	// TODO: Add proper check
	return false;
}

@Override
public MediaInfo getMediaInfo(String title, int width, int height)
{
	// TODO: Return proper media info
	return null;
}

@Override
public String makeUrl(PageTitle target)
{
	String page = UrlEncoding.WIKI.encode(target.getNormalizedFullTitle());
	String f = target.getFragment();
	String url = page;
	if (f != null && !f.isEmpty())
		url = page + "#" + UrlEncoding.WIKI.encode(f);
	return LOCAL_URL + "/" + url;
}

@Override
public String makeUrl(WtUrl target)
{
	if (target.getProtocol() == "")
		return target.getPath();
	return target.getProtocol() + ":" + target.getPath();
}

@Override
public String makeUrlMissingTarget(String path)
{
	return LOCAL_URL + "?title=" + path + "&amp;action=edit&amp;redlink=1";

}
}


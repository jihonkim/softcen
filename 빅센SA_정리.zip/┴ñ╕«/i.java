package bigcensaSample;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;

public interface i {
	 @Select("SELECT * FROM n20181118044118 where docid = #{tid}")
	 public Map getNumberOfBooks();
	 
	 @Select("SELECT * FROM n20181118044118 WHERE docid = #{CONCEPT_ID}")
	 public Map getXmlList(Map tmpM);
	 
	 @Select("SELECT * FROM bigcensa.WikiKorean")
	 public Map getDataList(Map paramMap);
	 
	 @Select("SELECT vocabulary_concept_id  FROM CDM.vocabulary WHERE vocabulary_id = #{vocaId}")
	 public String getVocaConceptId(String vocaId);
	 
	 @Insert("INSERT INTO bigcensa.WikiKorean" + 
	 		"(title, ns, id, r_id, r_parentid, r_timestamp, rc_username, rc_id, r_comment, r_model, r_format, r_text, r_sha1)" + 
	 		"VALUES(#{title},#{ns},#{id},#{r_id},#{parentid},#{timestamp},#{username},#{rc_id},#{comment},#{model},#{format},#{text},#{sha1})")
	 public void setInsertMap(Map paramMap);
/*	 @Insert("INSERT INTO CDM.note_nlp_test "
	 		+ "(note_id, section_concept_id, snippet,  offset_begin, lexical_variant, note_nlp_concept_id, note_nlp_source_concept_id, nlp_system, nlp_date, nlp_datetime)"
	 		+ " VALUES(#{note_id},#{section_concept_id},#{snippet},#{offset_begin},#{lexical_variant},#{note_nlp_concept_id},#{note_nlp_source_concept_id},#{nlp_system}, now(), now())")
	 public void setInsertMap(Map paramMap);*/
	 
/*	 @Insert("INSERT INTO cdm.t_table (asdf) VALUES('aaa')")
	 public void setinserttest();*/
}
